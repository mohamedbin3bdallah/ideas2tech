<!--==== footer ====  -->
<!--==== footer ====  -->
<footer>
    <div class="container">
        <div class="col-md-3 col-xs-6">
            <img src="<?php echo base_url(); ?>idea2tech/icons/logo-f.png" alt="">
        </div>
        
        <div class="col-md-3 col-xs-6">
            <ul class="list-unstyled">
                <li>COMPANY</li>
                <li><a href="<?php echo base_url(); ?>index-en">Home</a></li>
                <li><a href="<?php echo base_url(); ?>about-en">About us</a></li>
                <li><a href="<?php echo base_url(); ?>services-en">Services</a></li>
                <li><a href="<?php echo base_url(); ?>projects-en">Our Projects</a></li>
                <li><a href="#">Order Now</a></li>
            </ul>
        </div>
        
        <div class="col-md-3 col-xs-6">
            <ul class="list-unstyled">
                <li>DEVELOPERS</li>
                <li><a href="#">Web Development</a></li>
                <li><a href="#">App Development</a></li>
                <li><a href="#">SEO Markting</a></li>
                <li><a href="#">Theme</a></li>
                <li><a href="#">Development</a></li>
            </ul>
        </div>
        
        <div class="col-md-3 col-xs-6">
            <ul class="list-unstyled">
                <li>SUPPORT</li>
                <li><a href="<?php echo base_url(); ?>faqs-en">FAQ</a></li>
                <li><a href="#">Billing System</a></li>
            </ul>
        </div>
        
        
        
    
        
        </div>
        
         <div class="footer">
          <h5>IDEAS2TECH &#126; 2017 all Rights reserved</h5>
        </div> 
    </div>
    
    

    
</footer>   
    
    <script src="<?php echo base_url(); ?>idea2tech/js/jquery-3.2.1.min.js"></script>
	<?php $this->load->view('messages'); ?>
    <script src="<?php echo base_url(); ?>idea2tech/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>idea2tech/js/wow.min.js"></script>
	<script>new WOW().init();</script>
    <script src="<?php echo base_url(); ?>idea2tech/js/index.js"></script>
</body>