<!--====================================-->
<link rel="stylesheet" href="<?php echo base_url(); ?>idea2tech/css/about-us-ar.css">

<div class="about">
    <div class="container">
        <h1 class="head">ماذا عنا</h1>
        <div class="design"></div>
        <div class="text col-md-12 fadeInLeft wow" data-wow-duration='1.8s' data-wow-offset="300">
                <?php
					$about_lang = 'abdesc'.$front_lang;
					echo $about->$about_lang;
				?>
				<!--<h3><span>Ideas2Tech</span> has been in the IT industry for well  understanding the nuances of setting up a successful business which is so dependent on the ever changing technology. However, our idea of simplifying business requirements, providing a gamut of creative IT services. Our team of experts will help your business to achieve greater heights by having the most attractive, sophisticated websites yet utilizing our simplest graphic user interface.
                <br><br>
                We collaborate, listen and apply innovative and creative ideas to the app you have in mind. We understand breakthrough application solutions and are ready to apply brilliant and stunning design that will truly convert your idea into a successful live product ready to be shared and fascinate your customer.
                <br> <br>
                <span>Ideas2Tech</span> strives to provide our clients with dynamic Web Design as well as driven Website Design, Web Development, Advertising, Social Media, Digital Marketing, branding, business identity services, website updates, intriguing hosting services. based in Cairo.
                <br><br>
                We do understand that our quick and seamless adaptation to new technology and ideas makes us a force to reckon with. We are a one stop shop for all your IT needs. We can dedicate our state-of-the art resources to projects of all sizes .Gone are the days of brick and mortar set ups, now everything is online & accessible at a click of a button from anywhere in the world.
                <br><br>
                We bring your idea to life.
                <br><br>
                </h3>-->
        </div>
        
    </div>
</div>